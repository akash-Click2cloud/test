# encoding: utf-8
import warnings

import six
import time
import json

from footmark.connection import ACSQueryConnection
from footmark.vpc.regioninfo import RegionInfo
from footmark.vpc.securitygroup import SecurityGroup
from footmark.exception import VPCResponseError
from footmark.ecs.vrouter import VRouterList


class VPCConnection(ACSQueryConnection):
    #SDKVersion = footmark.config.get('Footmark', 'ecs_version', '2014-05-26')
    SDKVersion = '2014-05-26'
    DefaultRegionId = 'cn-hangzhou'
    DefaultRegionName = u'杭州'.encode("UTF-8")
    ResponseError = VPCResponseError

    def __init__(self, acs_access_key_id=None, acs_secret_access_key=None,
                 region=None, sdk_version=None, security_token=None, ):
        """
        Init method to create a new connection to ECS.
        """
        if not region:
            region = RegionInfo(self, self.DefaultRegionName,
                                self.DefaultRegionId)
        self.region = region
        if sdk_version:
            self.SDKVersion = sdk_version

        self.VPCSDK = 'aliyunsdkecs.request.v' + self.SDKVersion.replace('-', '')

        super(VPCConnection, self).__init__(acs_access_key_id,
                                            acs_secret_access_key,
                                            self.region, self.VPCSDK, security_token)

    def build_filter_params(self, params, filters):
        if not isinstance(filters, dict):
            return

        flag = 1
        for key, value in filters.items():
            acs_key = key
            if acs_key.startswith('tag:'):
                while ('set_Tag%dKey' % flag) in params:
                    flag += 1
                if flag < 6:
                    params['set_Tag%dKey' % flag] = acs_key[4:]
                    params['set_Tag%dValue' % flag] = filters[acs_key]
                flag += 1
                continue
            if key == 'group_id':
                if not value.startswith('sg-') or len(value) != 12:
                    warnings.warn("The group-id filter now requires a security group "
                                  "identifier (sg-*) instead of a security group ID. "
                                  "The group-id " + value + "may be invalid.",
                                  UserWarning)
                params['set_SecurityGroupId'] = value
                continue
            if not isinstance(value, dict):
                acs_key = ''.join(s.capitalize() for s in acs_key.split('_'))
                params['set_' + acs_key] = value
                continue

            self.build_filters_params(params, value)

    def delete_vswitch(self, vswitch_ids):
        """

        :type vswitch_ids: str
        :param vswitch_ids: The ID of the VSwitch to be deleted
        :return: return result of VSwitchIds
        """
    
        results = []
        instance_conn_vswitch = []
        changed = False
        try:
            response = self.get_vpc_info()
            instance_result = self.get_instance_info()
            data = instance_result[0]['Instances']
            for instance in data['Instance']:
                data_vpc = instance['VpcAttributes']
                if data_vpc['VSwitchId'] != "":
                    instance_conn_vswitch.append(data_vpc['VSwitchId'])
                                
            if len(response) > 0:              
                json_data = response[0]['Vpcs']
                for vswitch_id in vswitch_ids:
                    switch_status = False
                    for Items in json_data['Vpc']: 
                        desc_result = self.describe_vswitch(vswitch_ids=vswitch_id, vpc_id=Items['VpcId'])
                        json_vswitch_obj = desc_result[0].get('VSwitches')
                        if len(json_vswitch_obj['VSwitch'])>0:
                            if  int(desc_result[0].get('TotalCount')) == 1:
                                if json_vswitch_obj['VSwitch'][0].get('Status')== u'Available':
                                    switch_status = True
                                    v_ids = {}
                                    if vswitch_id not in instance_conn_VSwitch:
                                        self.build_list_params(v_ids, vswitch_id, 'VSwitchId')
                                        del_result = self.get_status('DeleteVSwitch',v_ids)
                                        changed = True
                                        result_final = { "status": '%s deleted'%vswitch_id,"flag": True}
                                        results.append(result_final)
                                        break 
                                    else:
                                        result_final = { "status": '%s object has dependent resources.'
                                                                   ''%vswitch_id,"flag": False}
                                        results.append(result_final)
                    if not switch_status:
                        result_final = { "status": '%s vswitch is not available to be deleted' %
                                                   vswitch_id, "flag": False}
                        results.append(result_final)
        except Exception as ex:                       
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})

        return changed, results

    def get_vpc_info(self):
        """
        method to get all vpcId of particular region 
        :return: Return All vpcs in the region
        """
        params = {}
        results = []

        try:
            v_ids = {}
            response = self.get_status('DescribeVpcs', params)
            results.append(response)
            
        except Exception as ex:        
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return results

    
    def get_instance_info(self):
        """
        method to get all Instances of particular region 
        :return: Return All Instances in the region
        """
        params = {}
        results = []

        try:
            v_ids = {}
            response = self.get_status('DescribeInstances', params)
            results.append(response)
            
        except Exception as ex:        
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return results


    def describe_vswitch(self, vswitch_ids, vpc_id):
        """
        method to check vswitch present or not       
        :type VpcId : str
        :param VpcId: The Id of vpc in which switch is present
        :type vswitch_ids :str
        :param vswitch_ids: The Id of vswitch to be describe
        :return: Return the status of the vswitch
        """
        params = {}
        results = []

        try:     
                             
            self.build_list_params(params, vswitch_ids, 'VSwitchId')
            self.build_list_params(params, vpc_id, 'VpcId')
            response = self.get_status('DescribeVSwitches', params)
            results.append(response)
            
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return results

    def requesting_eip_addresses(self, bandwidth, internet_charge_type):
        """
        method to query eip addresses in the region
        :type bandwidth : str
        :param bandwidth : bandwidth of the eip address
        :type internet_charge_type : str
        :param internet_charge_type : paybytraffic or paybybandwidth types
        :return: Return the allocationId , requestId and EIP address
        """
        params = {}
        results = []
        changed = False
        try:
            if bandwidth:
                self.build_list_params(params, bandwidth, 'Bandwidth')
            
            if internet_charge_type:
                self.build_list_params(params, internet_charge_type, 'InternetChargeType')
                        
                  
            results = self.get_status('AllocateEipAddress', params)
            changed = True
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return changed, results

    def releasing_eip(self, allocation_ids):
        """
        To release Elastic Ip

        :type allocation_ids: list
        :param allocation_ids: To release the allocation ID,allocation ID uniquely identifies the EIP
        :return: Return status of operation
        """
        params = {}
        results = []

        try:
            for item in allocation_ids:
                allocation_id = item
                self.build_list_params(params, allocation_id, 'AllocationId')
                results.append(self.get_status('ReleaseEipAddress', params))

        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return results

    def bind_eip(self, allocation_id, instance_id):
        """
        :type allocation_id:string
        :param allocation_id:The instance ID of the EIP
        :type instance_id:string
        :param instance_id:The ID of an ECS instance
        :return:Returns the status of operation
        """
        params = {}
        results = []
        
        self.build_list_params(params, allocation_id, 'AllocationId')
        self.build_list_params(params, instance_id, 'InstanceId')
       
        try:
            results = self.get_status('AssociateEipAddress', params)
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
       
        return results

    def unbind_eip(self, allocation_id, instance_id):
        """
        :type allocation_id:string
        :param allocation_id:The instance ID of the EIP
        :type instance_id:string
        :param instance_id:The ID of an ECS instance
        :return:Request Id
        """
        params = {}
        results = []
        changed = False
        if allocation_id:
            self.build_list_params(params, allocation_id, 'AllocationId')
        if instance_id:
            self.build_list_params(params, instance_id, 'InstanceId')
        try:
            results = self.get_status('UnassociateEipAddress', params)
            changed = True
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return changed, results
        
    def modifying_eip_attributes(self, allocation_id, bandwidth):
        """
        :type allocation_id:string
        :param allocation_id:The instance ID of the EIP
        :type bandwidth:string
        :param bandwidth:Bandwidth of the EIP instance
        :return:Request Id
        """
        params = {}
        results = []
        changed = False

        if allocation_id:
            self.build_list_params(params, allocation_id, 'AllocationId')
        if bandwidth:
            self.build_list_params(params, bandwidth, 'Bandwidth')
        try:
            results = self.get_status('ModifyEipAddressAttribute', params)
            changed = True
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return changed, results

    def get_all_vrouters(self, vrouter_ids=None):
        """
        Query the Vrouters for the region

        :type vrouter_ids: list
        :param vrouter_ids: List of VRouter_Ids to be fetched

        :return: List of VRouters in json format
        """
        params = {}
        results = []
        cnt = 0
        try:
            if vrouter_ids:
                cnt = len(vrouter_ids)

                # query for each vrouter
                for counter in range(0, cnt):
                    v_id = vrouter_ids[counter]

                    # Id of vRouter which is to be queried
                    self.build_list_params(params, v_id, 'VRouterId')
                    results.append(self.get_list('DescribeVRouters', params, ['VRouters', VRouterList]))
            else:
                results.append(self.get_list('DescribeVRouters', params, ['VRouters', VRouterList]))
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return results

    def delete_custom_route(self, route_table_id, destination_cidr_block, next_hop_id):
        """
        Deletes the specified RouteEntry for the vpc

        :type route_table_id: string
        :param route_table_id: Id of the route table

        :type destination_cidr_block: string
        :param destination_cidr_block: The RouteEntry's target network segment

        :type next_hop_id: string
        :param next_hop_id: The route entry's next hop

        :return: Return status of operation
        """
        params = {}
        results = []

        self.build_list_params(params, route_table_id, 'RouteTableId')
        self.build_list_params(params, destination_cidr_block, 'DestinationCidrBlock')
        self.build_list_params(params, next_hop_id, 'NextHopId')

        try:
            results = self.get_status('DeleteRouteEntry', params)
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return results

    def releasing_eip(self, allocation_ids):
        """
        To release Elastic Ip

        :type allocation_ids: list
        :param allocation_ids: To release the allocation ID,allocation ID uniquely identifies the EIP
        :return: Return status of operation
        """
        params = {}
        results = []

        for item in allocation_ids:
            try:
                allocation_id = item
                self.build_list_params(params, allocation_id, 'AllocationId')
                obtained_result = self.get_status('ReleaseEipAddress', params)
                results.append(obtained_result)

            except Exception as ex:
                error_code = ex.error_code
                error_msg = ex.message
                msg = 'Release Eip failed for ' + allocation_id
                results.append(msg)
                results.append("Error Code: " + error_code)
                results.append("Error Message: " + error_msg)

        return results

    def create_vpc(self, cidr_block=None, user_cidr=None, vpc_name=None, description=None, subnet=None,
                   route_tables=None):  

        """
        Create a ECS VPC (virtual private cloud) in Aliyun Cloud
        :type cidr_block: String
        :param cidr_block: The cidr block representing the VPC, e.g. 10.0.0.0/8
        :type user_cidr: String
        :param user_cidr: User custom cidr in the VPC
        :type vpc_name: String
        :param vpc_name: A VPC name
        :type description: String
        :param description: Description about VPC
        :type subnet: List
        :param subnet: List of Dictionary of Parameters for creating subnet(vswitch)
        :type route_tables: List
        :param route_tables: List of Dictionary of Parameters for creating RouteEntry
        :return: Returns details of created VPC
        """

        params = {}
        results = []
        changed = False

        if cidr_block:
            self.build_list_params(params, cidr_block, 'CidrBlock')

        if user_cidr:
            self.build_list_params(params, user_cidr, 'UserCidr')

        if vpc_name:
            self.build_list_params(params, vpc_name, 'VpcName')

        if description:
            self.build_list_params(params, description, 'Description')

        try:
            response = self.get_status('CreateVpc', params)
            vpc_id = str(response['VpcId'])
            route_table_id = str(response['RouteTableId'])
            results.append(response)
            changed = True
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        else:
            # creating vswitch(subnet) after creation of VPC
            time.sleep(30)
            if subnet:
                for val in subnet:
                    cidr = None
                    az = None
                    name = None
                    description = None
                    if 'cidr' in val:
                        cidr = val['cidr']
                    if 'az' in val:
                        az = val['az']
                    if 'name' in val:
                        name = val['name']
                    if 'description' in val:
                        description = val['description']
                    vswitch_response = self.create_vswitch(vpc_id=vpc_id, cidr=cidr, zone_id=az, vswitch_name=name,
                                                           description=description)
                    results.append(vswitch_response[1])

            # creating route entry after creation of VPC
            if route_tables:
                for route_table in route_tables:
                    dest = None
                    next_hop_type = None
                    next_hop_id = None
                    if 'dest' in route_table:
                        dest = route_table['dest']
                    if 'next_hop_type' in route_table:
                        next_hop_type = route_table['next_hop_type']
                    if 'next_hop_id' in route_table:
                        next_hop_id = route_table['next_hop_id']
                    route_table_response = self.create_route_entry(route_table_id=route_table_id, dest=dest,
                                                                   next_hop_type=next_hop_type, next_hop_id=next_hop_id)
                    results.append(route_table_response[1])

        return changed, results

    def create_vswitch(self, zone_id, cidr, vpc_id, vswitch_name=None, description=None):
        """

        :type zone_id: String
        :param zone_id: Zone Id is specific zone inside region that we worked

        :type cidr: String
        :param cidr: The network address allocated to the new VSwitch

        :type vpc_id: String
        :param vpc_id: The VPC of the new VSwitch

        :type vswitch_name: string
        :param vswitch_name: The VSwitch name. The default value is blank. [2, 128] English or Chinese characters,
         must begin with an uppercase/lowercase letter or Chinese character. Can contain numbers, "_" and "-".
         This value will appear on the console.It cannot begin with http:// or https://.

        :type description: string
        :param description: The VSwitch description. The default value is blank. [2, 256] English or Chinese characters.
         Cannot begin with http:// or https://.

        :return: VSwitchId The system allocated VSwitchID
        """
        params = {}
        results = []
        changed = False
        VSwitchId = None

        if zone_id:
            self.build_list_params(params, zone_id, 'ZoneId')
        if cidr:
            self.build_list_params(params, cidr, 'CidrBlock')
        if vpc_id:
            self.build_list_params(params, vpc_id, 'VpcId')
        if vswitch_name:
            self.build_list_params(params, vswitch_name, 'VSwitchName')
        if description:
            self.build_list_params(params, description, 'Description')

        try:
            response = self.get_status('CreateVSwitch', params)
            results.append(response)
            VSwitchId = response[u'VSwitchId']
            changed = True
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return changed, results, VSwitchId

    def create_route_entry(self, route_table_id, dest, next_hop_type=None, next_hop_id=None):

        """
        Create RouteEntry for VPC
        :type route_table_id: String
        :param route_table_id: ID of VPC Route Table
        :type dest: String
        :param dest: It must be a legal CIDR or IP address, such as: 192.168.0.0/24 or 192.168.0.1
        :type next_hop_type:
        :param next_hop_type: The next hop type. Available value options: Instance or Tunnel
        :type next_hop_id:
        :param next_hop_id: The route entry's next hop
        :return: Returns details of RouteEntry
        """
        params = {}
        results = []
        changed = False

        if route_table_id:
            self.build_list_params(params, route_table_id, 'RouteTableId')
        if dest:
            self.build_list_params(params, dest, 'DestinationCidrBlock')
        if next_hop_type:
            self.build_list_params(params, next_hop_type, 'NextHopType')
        if next_hop_id:
            self.build_list_params(params, next_hop_id, 'NextHopId')

        try:
            response = self.get_status('CreateRouteEntry', params)
            results.append(response)
            changed = True
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return changed, results

    def get_vswitch_status(self, vpc_id, zone_id=None, vswitch_id=None, page_number=None, page_size=None):

        """
        List VSwitches of VPC with their status
        :type vpc_id: string
        :param vpc_id: ID of Vpc from which VSwitch belongs
        :type zone_id: string
        :param zone_id: ID of the Zone
        :type vswitch_id: string
        :param vswitch_id: The ID of the VSwitch to be queried
        :type page_number: integer
        :param page_number: Page number of the instance status list. The start value is 1. The default value is 1
        :type page_size: integer
        :param page_size: The number of lines per page set for paging query. The maximum value is 50 and default
        value is 10
        :return: Returns list of VSwiches in VPC with their status
        """
        params = {}
        results = []
        changed = False

        self.build_list_params(params, vpc_id, 'VpcId')
        if zone_id:
            self.build_list_params(params, zone_id, 'ZoneId')
        if vswitch_id:
            self.build_list_params(params, vswitch_id, 'VSwitchId')
        if page_number:
            self.build_list_params(params, page_number, 'PageNumber')
        if page_size:
            self.build_list_params(params, page_size, 'PageSize')

        try:
            results = self.get_status('DescribeVSwitches', params)
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return changed, results


    def delete_vpc(self, vpc_id=None):
        """
               Delete Vpc

               :type vpc_id: string
               :param vpc_id: Vpc Id of the targeted Vpc to terminate

               :rtype: dict
               :return: Returns a dictionary of Vpc Details that is targeted. If the Vpc was not deleted or found,
               "changed" will be set to False.


               """
        results = []
        changed = False

        params = {}

        if vpc_id:
            self.build_list_params(params, vpc_id, 'VpcId')

        try:
            response = self.get_status('DeleteVpc', params)
            changed = True
            results.append("Vpc with Id " + vpc_id + " successfully deleted.")
        except Exception as ex:
            error_code = ex.error_code
            msg = ex.message
            error_dict = {
                'DependencyViolation.RouteEntry': 'Custom route rules still exist for the current VPC. VPC deletion failed',
                'DependencyViolation.Instance': 'Cloud product instances still exist for the current VPC. VPC deletion failed',
                'DependencyViolation.VSwitch': 'VSwitches still exist for the current VPC. VPC deletion failed',
                'DependencyViolation.SecurityGroup': 'Security groups still exist for the current VPC. VPC deletion failed',
                'IncorrectVpcStatus': 'The current VPC status does not support this operation'}

            results.append("Following error occurred while deleting Vpc with Id "+vpc_id)
            results.append("Error Code: " + error_code)
            if error_code in error_dict:
                results.append("Message: " + str(error_dict[error_code]))
            else:
                results.append("Message: " + str(msg))


        return changed, results

    def get_vpcs(self, vpc_id=None, region_id=None):
        """
           Find Vpc

           :type vpc_id: string
           :param vpc_id: Vpc Id of the targeted Vpc to terminate

            :type region_id: string
           :param region_id: Region Id to locate Vpc in

           :rtype: bool
           :return: Returns True if vpc found along with Vpc details else False with possible reason.


           """

        params = {}

        if region_id:
            self.build_list_params(params, region_id, 'RegionId')

        if vpc_id:
            self.build_list_params(params, vpc_id, 'VpcId')

        try:
            response = self.get_status('DescribeVpcs', params)
            vpc_result = response['Vpcs']['Vpc']
            if len(vpc_result) > 0:
                return True, vpc_result
            else:
                return False, "Vpc does not exist"
        except Exception as ex:
            msg, stack = ex.args
            return False, "error occurred while finding Vpc :" + str(msg) + " " + str(stack)


