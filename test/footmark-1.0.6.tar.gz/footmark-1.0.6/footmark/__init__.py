#
import logging
import logging.config
import os

from footmark.pyami.config import Config, FootmarkLoggingConfig, DefaultLoggingConfig

__version__ = '1.0.6'
Version = __version__  # for backware compatibility

def init_logging():
    try:
        Config().init_config()
        try:
            logging.config.fileConfig(os.path.expanduser(FootmarkLoggingConfig))
        except:
            logging.config.dictConfig(DefaultLoggingConfig)
    except:
        pass

init_logging()
log = logging.getLogger('footmark')


def connect_ecs(acs_access_key_id=None, acs_secret_access_key=None, **kwargs):
    """
    :type acs_access_key_id: string
    :param acs_access_key_id: Your AWS Access Key ID

    :type acs_secret_access_key: string
    :param acs_secret_access_key: Your AWS Secret Access Key

    :rtype: :class:`footmark.ecs.connection.ECSConnection`
    :return: A connection to Amazon's ECS
    """
    from footmark.ecs.connection import ECSConnection
    return ECSConnection(acs_access_key_id, acs_secret_access_key, **kwargs)


def connect_slb(acs_access_key_id=None, acs_secret_access_key=None, **kwargs):
    """
    :type acs_access_key_id: string
    :param acs_access_key_id: Your AWS Access Key ID

    :type acs_secret_access_key: string
    :param acs_secret_access_key: Your AWS Secret Access Key

    :rtype: :class:`footmark.ecs.connection.ECSConnection`
    :return: A connection to Amazon's SLB
    """
    from footmark.slb.connection import SLBConnection
    return SLBConnection(acs_access_key_id, acs_secret_access_key, **kwargs)


def connect_vpc(acs_access_key_id=None, acs_secret_access_key=None, **kwargs):
    """
    :type acs_access_key_id: string
    :param acs_access_key_id: Your AWS Access Key ID

    :type acs_secret_access_key: string
    :param acs_secret_access_key: Your AWS Secret Access Key

    :rtype: :class:`footmark.vpc.connection.ECSConnection`
    :return: A connection to Amazon's VPC
    """
    from footmark.vpc.connection import VPCConnection
    return VPCConnection(acs_access_key_id, acs_secret_access_key, **kwargs)

#acs_access_key_id = "LTAIV7yukr6Csf14"
#acs_secret_access_key = "it9TEJcJvnDyL5uB830fx1BQwzdNdd"
##instance_ids = "i-j6c5txh3q0wivxt5m807"
##group_id = "sg-j6c8bincxdak9xde7j0p"
#region_id = "cn-hongkong"
#snapshot_id = "s-j6chwdby6fkuzbxnsd82"
#disk_id = "d-2zea1m4frj5syfrvar12"
#instance_id = "i-rj95iytyo4d16kxqj58a"
##launch_permission =  {'user_ids': ['contact@click2cloud.net']}

###{'user_ids': ['user1', 'user2', 'user3', 'user4', 'user5']}
##image_id = 'm-rj9d7yk4rbq8e9va4odd'
#tags= [{'tag_key':'a1', 'tag_value':'1'},{'tag_key':'a2', 'tag_value':'2'},{'tag_key':'a3', 'tag_value':'3'}]
#disk_mapping=[{'snapshot_id':'s-j6cfg4lsb6wmo22hde4o','device':'/dev/xvda'}]
#conn = connect_ecs(acs_access_key_id,acs_secret_access_key,region=region_id)
#result = conn.create_image( snapshot_id=None, image_name=None, image_version=5, description="akash",
#                     images_tags=None, instance_id=None, disk_mapping=disk_mapping, launch_permission=None,
#                     wait="yes", wait_timeout="10")
